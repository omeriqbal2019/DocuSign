 export class  TokenModel {
 access_token:string | null | undefined;
  public setToken(token:string): void {
   this.access_token=token;
    //sessionStorage.setItem('accessToken', token);
  }

  public getToken() {
  return  this.access_token;
  }
}

export class DocuSignRequestModel
{
     signerEmail!: string | null; 
     signerName!:string  | null; 
     offerId!:string  | null; 

}
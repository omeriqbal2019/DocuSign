import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { DocuSignRequestModel } from '../Model/DocuSignRequestModel';
import { environment } from 'src/environment';
import { TokenModel } from '../Model/TokenModel';
@Injectable({
  providedIn: 'root'
})
export class DocuSignServiceService {
  private statuses = ['sent', 'delivered', 'opened', 'signed', 'completed'];
private apiUrl =environment.API_BASE;
  constructor(private http: HttpClient) { }

 initiateDocusignLogin(): void {
    const authUrl = `https://account-d.docusign.com/oauth/auth?response_type=token&scope=signature&client_id=${environment.Client_ID}&redirect_uri=${environment.REDIRECT_URI}`;
    window.location.href = authUrl;
this.handleCallback();
  }
    handleCallback(): void {
    const fragment = window.location.hash.substring(1);
    const params = new URLSearchParams(fragment);
    const accessToken = params.get('access_token');
    if (this.validateTokenExpiry()==false){
if (accessToken) {
      sessionStorage.setItem('docusign_access_token', accessToken);
      console.log('Access Token:', accessToken);
      var tokenmodel=new TokenModel();
      tokenmodel.setToken(accessToken);
              this.SetToken(tokenmodel.getToken()).subscribe({
              next: (res) => {
              },
              error: (err) => console.error('Get Token failed', err)
            });
    }
    }
    
  }
  validateTokenExpiry():boolean{
     const fragment = window.location.hash.substring(1);
  const params = new URLSearchParams(fragment);
  const expiresIn = params.get('expires_in');
  
  // Return false if no expires_in parameter found
  if (!expiresIn) return false;
  
  // Convert string to number
  const expiresInSeconds = parseInt(expiresIn, 10);
  
  // Return false if conversion failed
  if (isNaN(expiresInSeconds)) return false;
  
  const tokenExpiresTime = new Date();
  tokenExpiresTime.setSeconds(tokenExpiresTime.getSeconds() + expiresInSeconds);
  
  // Subtract 1 second as buffer
  tokenExpiresTime.setSeconds(tokenExpiresTime.getSeconds() - 1);
  
  return new Date() < tokenExpiresTime;
  }
   SetToken(token:any) {
    return this.http.post(`${this.apiUrl}/DocuSign/SetJwtToken`, {
      token
    });
  }
  sendForSignature(name: string, email: string, pdfUrl: string): Observable<string> {
    return new Observable(observer => {
      setTimeout(() => {
        const envelopeId = 'env-' + Math.random().toString(36).substr(2, 9);
        observer.next(envelopeId);
        observer.complete();
      }, 1000);
    });
  }

  getStatusUpdates(envelopeId: string): Observable<string> {
    return new Observable(observer => {
      let currentStatusIndex = 0;
      
      const interval = setInterval(() => {
        if (currentStatusIndex < this.statuses.length) {
          observer.next(this.statuses[currentStatusIndex]);
          currentStatusIndex++;
        } else {
          clearInterval(interval);
          observer.complete();
        }
      }, 3000);
    });
  }

   sendToSignature(obj:any) {
    return this.http.post<{ redirectUrl: string }>(`${this.apiUrl}/DocuSign/sendForSignature`, {
      obj
    });
  }

}

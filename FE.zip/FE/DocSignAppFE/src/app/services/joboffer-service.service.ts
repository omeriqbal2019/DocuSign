import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { jsPDF } from 'jspdf';
@Injectable({
  providedIn: 'root'
})
export class JobofferServiceService {

   constructor(private http: HttpClient) {}

  generatePdf(formData: any): Observable<Blob> {
    return new Observable(observer => {
      try {
        const pdf = new jsPDF();
        
        // Set title
        pdf.setFontSize(18);
        pdf.text('OFFICIAL JOB OFFER', 105, 20, { align: 'center' });
        
        // Add recipient information
        pdf.setFontSize(12);
        pdf.text(`To: ${formData.recipientName}`, 20, 40);
        pdf.text(`Email: ${formData.recipientEmail}`, 20, 50);
        
        // Add content
        pdf.setFontSize(11);
        const content = this.stripHtml(formData.content);
        const lines = pdf.splitTextToSize(content, 370);
        pdf.text(lines, 20, 60);
        
        // Generate PDF blob
        const blob = pdf.output('blob');
        observer.next(blob);
        observer.complete();
      } catch (error) {
        observer.error(error);
      }
    });
  }

  private stripHtml(html: string): string {
    // Create a temporary div to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    
    // Replace bullet points with dashes
    const listItems = tempDiv.querySelectorAll('li');
    listItems.forEach(li => {
      li.textContent = '• ' + li.textContent;
    });
    
    // Get text content with line breaks preserved
    return tempDiv.innerText || tempDiv.textContent || '';
  }
  private apiUrl = 'https://localhost:44350/api/PDF';
    CreatePdf(formData: any) {
const headers = new HttpHeaders({
 'Access-Control-Allow-Origin' : '*'
});

  return this.http.post<{ pdfModel: string }>(`${this.apiUrl}/generate`,formData,{ headers });


    //return this.http.post<{ offerId: string }>(`${this.apiUrl}/generate`, formData,{this.headers});
  }
}

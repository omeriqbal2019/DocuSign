import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JobOfferComponent } from './ui-component/JobOffer/job-offer/job-offer.component';

const routes: Routes = [
  

     { path: '', redirectTo: '/job-offer', pathMatch: 'full' },
  { path: 'job-offer', component: JobOfferComponent }

  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

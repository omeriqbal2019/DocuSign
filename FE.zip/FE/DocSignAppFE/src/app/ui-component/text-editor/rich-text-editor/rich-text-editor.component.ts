
import { Component, Input, Output, EventEmitter,ViewChild,SimpleChanges } from '@angular/core';
import { CKEditorComponent } from 'ng2-ckeditor';
@Component({
 selector: 'app-rich-text-editor',
  templateUrl: './rich-text-editor.component.html',
  styleUrls: ['./rich-text-editor.component.css'],

})
export class RichTextEditorComponent {
     @Input() content: string = '';
  @Output() contentChange = new EventEmitter<string>();
   private lastExternalContent: string = '';
  @ViewChild(CKEditorComponent) ckeditor?: CKEditorComponent;
  editorContent: string = '';

  config: any = {
    toolbar: [
      { name: 'basic', items: ['Bold', 'Italic', 'Underline'] },
      { name: 'lists', items: ['BulletedList', 'NumberedList'] },
      { name: 'links', items: ['Link', 'Unlink'] },
      { name: 'document', items: ['Source'] }
    ],
    height: 400,
    removePlugins: 'elementspath',
    resize_enabled: false
  };
ngOnInit() {
    this.editorContent = this.content;
    this.lastExternalContent = this.content;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['content'] && changes['content'].currentValue !== this.lastExternalContent) {
      this.editorContent = changes['content'].currentValue;
      this.lastExternalContent = this.editorContent;
      
      if (this.ckeditor?.instance) {
        this.ckeditor.instance.setData(this.editorContent);
      }
    }
  }

  onEditorChange() {
    if (this.ckeditor?.instance) {
      const newContent = this.ckeditor.instance.getData();
      
      if (newContent !== this.lastExternalContent) {
        this.editorContent = newContent;
        this.contentChange.emit(newContent);
      }
    }
  }

}
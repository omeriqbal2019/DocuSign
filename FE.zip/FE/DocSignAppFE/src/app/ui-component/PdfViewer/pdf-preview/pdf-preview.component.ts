
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
@Component({
  selector: 'app-pdf-preview',
  templateUrl: './pdf-preview.component.html',
  styleUrls: ['./pdf-preview.component.css']
})
export class PdfPreviewComponent {
 @Input() pdfUrl: string | null = null;
  page: number = 1;
  totalPages: number = 0;
  isLoaded: boolean = false;
  pdfData: Uint8Array | null = null;

  ngOnChanges(changes: SimpleChanges) {
    if (changes['pdfUrl'] && this.pdfUrl) {
      this.loadPdf();
    }
  }

  async loadPdf() {
    if (!this.pdfUrl) return;
    
    try {
      // Fetch the PDF as ArrayBuffer
      debugger;
      const response = await fetch(this.pdfUrl);
      const arrayBuffer = await response.arrayBuffer();
      this.pdfData = new Uint8Array(arrayBuffer);
      this.page = 1;
      this.isLoaded = false;
    } catch (error) {
      console.error('Error loading PDF:', error);
    }
  }

  afterLoadComplete(pdf: any) {
    this.totalPages = pdf.numPages;
    this.isLoaded = true;
  }

  prevPage() {
    this.page = this.page > 1 ? this.page - 1 : 1;
  }

  nextPage() {
    this.page = this.page < this.totalPages ? this.page + 1 : this.totalPages;
  }
}

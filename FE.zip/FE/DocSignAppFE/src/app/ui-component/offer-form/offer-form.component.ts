import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  EventEmitter, Output } from '@angular/core';
import { JobofferServiceService } from '../../services/joboffer-service.service';
import {  DocuSignServiceService } from '../../services/docu-sign-service.service';
import { DatePipe } from '@angular/common';
import { DocuSignRequestModel } from 'src/app/Model/DocuSignRequestModel';
import { TokenModel } from 'src/app/Model/TokenModel';
@Component({
  selector: 'app-offer-form',
  templateUrl: './offer-form.component.html',
  styleUrls: ['./offer-form.component.css'],
    providers: [DatePipe]
})
export class OfferFormComponent implements OnInit {
      isCallbackRoute = false;
      isLoading=false;
 offerForm: FormGroup;
  pdfUrl: string | null = null;
  isGenerating = false;
  defaultTemplate = `
    <p>Hi [Candidate Name],</p>
    <p>We're excited to offer you the <strong>[Position Title]</strong> role at <strong>[Company Name]</strong>!</p>
    <ul>
      <li><strong>Start Date:</strong> [Start Date]</li>
      <li><strong>Salary:</strong> [Amount]</li>
      <li><strong>Location:</strong> [Location]</li>
      <li><strong>Schedule:</strong> [Schedule]</li>
    </ul>
    <p>Please confirm your acceptance by replying to this email or signing the attached offer letter by <strong>[Deadline]</strong>.</p>
    <p>We can't wait to have you on the team! </p><br/>
    <p>Best,<br/></p>
    <p>[Your Name]<br/></p>
    <p>[Your Position]<br/></p>
    <p>[Your Company]<br/></p>`;
  
  @Output() envelopeCreated = new EventEmitter<string>();
  private originalTemplate = this.defaultTemplate;
   locationOptions = ['Remote', 'OnSite', 'Hybrid'];
  scheduleOptions = ['Full-time', 'Part-time', 'Contract'];
 positionOptions = ['Junior', 'Software Developer', 'Software Engineer', 'Senior Software Engineer', 'Lead Software Engineer', 'Architect'];
  constructor(
    private fb: FormBuilder,
    private offerService: JobofferServiceService,
    private docusignService: DocuSignServiceService,
        private datePipe: DatePipe
  ) {
    this.offerForm = this.fb.group({
      recipientName: ['', Validators.required],
      recipientEmail: ['', Validators.required],
     startDate: ['',Validators.required],
      salary: ['', Validators.required],
      location: ['',Validators.required],
      schedule: ['', Validators.required],
            position: ['', Validators.required],
      content: this.defaultTemplate
      
    });

  this.offerForm.valueChanges.subscribe(() => {
      this.updateAllPlaceholders();
    });
  }
    pdfData: Uint8Array | null = null;
offerId:string | null = null;
   ngOnInit() {
    debugger;
 if (window.location.href.indexOf("access_token")<0) {
      this.isCallbackRoute = true;
      this.docusignService.initiateDocusignLogin();
    }
    else if (window.location.href.indexOf("access_token")>0)
       this.docusignService.handleCallback();
  }
  markFormGroupTouched(formGroup: FormGroup) {
    if (Reflect.getOwnPropertyDescriptor(formGroup, 'controls')) {
      (<any>Object).values(formGroup.controls).forEach((control: FormGroup<any>) => {
        if (control instanceof FormGroup) {
          // FormGroup
          this.markFormGroupTouched(control);
        }
        // FormControl
        control.markAsTouched();
      });
    }
  }

  generateOfferLetter() {

      this.markFormGroupTouched(this.offerForm)
   
    if (this.offerForm.invalid) {
       this.isGenerating = false;
        this.isLoading=false;
      return;
    }

 this.isLoading=true;
      this.isGenerating = true;

           let obj = {"recipientName":"","recipientEmail":"","content":""}
      
       obj["recipientName"] = this.offerForm.get("recipientName")?.value;
      obj["recipientEmail"] = this.offerForm.get("recipientEmail")?.value;
   obj["content"] = this.offerForm.get("content")?.value;
   //"<div><p>To:"+this.offerForm.get("recipientName")?.value+"</p></div><div><p>Email :"+this.offerForm.get("recipientEmail")?.value+"</p></div><br/><br/>"+
         this.offerService.CreatePdf(obj).subscribe({ 
        next: async (res:any) => {
     
          this.offerId=res.offerId;
         this.isGenerating = true;

      this.offerService.generatePdf(this.offerForm.value).subscribe({
        next: (pdfBlob) => {
          const blobUrl = URL.createObjectURL(pdfBlob);
          this.pdfUrl = blobUrl;
          this.isGenerating = false;
           this.isLoading=false;
        },
        error: () => this.isGenerating = false
      });

          this.isGenerating = false;
        },
        error: (err) => console.error('PDF generation failed', err)
      });
   
  }

  sendForSignature() {

       const signerEmail = this.offerForm.get("recipientEmail")!.value.trim();
  const signerName = this.offerForm.get("recipientName")!.value.trim();
  const offerId = this.offerId!;


 let obj = {"signerEmail":"","signerName":"","offerId":""}
      obj["signerEmail"] = signerEmail;
      obj["signerName"] = signerName;
      obj["offerId"] = offerId;
this.isLoading=true;
this.docusignService.sendToSignature(obj).subscribe({
        next: (res) => {
          this.isLoading=false;
  const url = res?.redirectUrl;
  window.open(url, '_blank', 'noopener,noreferrer');
        },
        error: (err) => console.error('PDF generation failed', err) 
      });
    }

  
updateAllPlaceholders(): void {
    const contentControl = this.offerForm.get('content');
    if (!contentControl) return;

    const formValues = this.offerForm.value;
    let newContent = this.originalTemplate;
    
    let formattedDate = '[Start Date]';
    if (formValues.startDate) {
      formattedDate = this.datePipe.transform(formValues.startDate, 'MMM d, yyyy') || '[Start Date]';
    }
    
    let formattedSalary = '[Amount]';
    if (formValues.salary) {
      formattedSalary = '$' + parseInt(formValues.salary).toLocaleString('en-US');
    }

const today = new Date(); 
const daysToAdd = 5;
const futureDate = new Date();
futureDate.setDate(today.getDate() + daysToAdd);

    const placeholders = {
      '[Candidate Name]': formValues.recipientName || '[Candidate Name]',
      '[Start Date]': formattedDate,
      '[Amount]': formattedSalary,
      '[Location]': formValues.location || '[Location]',
      '[Schedule]': formValues.schedule || '[Schedule]',
      '[Your Name]': 'Zaheer Ahmed',
      '[Deadline]': this.datePipe.transform(futureDate, 'MMM d, yyyy') || '[Deadline]',
      '[Position Title]': formValues.position || '[Position Title]',
      '[Your Position]':'HR Manager',
      '[Company Name]':'Smart Dev Technologies',
      '[Your Company]':'Smart Dev Technologies'
    };

    Object.keys(placeholders).forEach(placeholder => {
      const regex = new RegExp(this.escapeRegExp(placeholder), 'g');
      newContent = newContent.replace(regex, (placeholders as any)[placeholder]);
    });

    contentControl.setValue(newContent, { emitEvent: false });
  }
  private escapeRegExp(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  
}

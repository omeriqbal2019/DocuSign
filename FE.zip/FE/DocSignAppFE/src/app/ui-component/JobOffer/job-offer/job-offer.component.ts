import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DocuSignServiceService } from 'src/app/services/docu-sign-service.service';
import { JobofferServiceService } from 'src/app/services/joboffer-service.service';
@Component({
  selector: 'app-job-offer',
  templateUrl: './job-offer.component.html',
  styleUrls: ['./job-offer.component.css']
})
export class JobOfferComponent {
   currentStatus: string = '';
  statusUpdates: string[] = [];
  tracking = false;

  constructor(private docusignService: DocuSignServiceService) {}

  trackStatus(envelopeId: string) {
    this.tracking = true;
    this.statusUpdates = [];
    
    this.docusignService.getStatusUpdates(envelopeId).subscribe({
      next: status => {
        this.currentStatus = status;
        this.statusUpdates.push(`${new Date().toLocaleTimeString()}: ${status}`);
      },
      complete: () => this.tracking = false
    });
  }
}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JobOfferComponent } from './ui-component/JobOffer/job-offer/job-offer.component';
import { PdfPreviewComponent } from './ui-component/PdfViewer/pdf-preview/pdf-preview.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RichTextEditorComponent } from './ui-component/text-editor/rich-text-editor/rich-text-editor.component';
import { OfferFormComponent } from './ui-component/offer-form/offer-form.component';
import { FormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
// Set worker source
@NgModule({
  declarations: [
    AppComponent,
    JobOfferComponent,
    PdfPreviewComponent,
    RichTextEditorComponent,
    OfferFormComponent,
  ],
  imports: [
  BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    PdfViewerModule,
    AppRoutingModule,CKEditorModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

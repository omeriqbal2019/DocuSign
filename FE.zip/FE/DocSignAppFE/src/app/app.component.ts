import { Component, OnInit } from '@angular/core';
import { DocuSignServiceService } from 'src/app/services/docu-sign-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent   {
title = 'Job Offer Management System';
   isCallbackRoute = false;

  

}

export const environment = {
  
    API_BASE: 'https://localhost:44350/api',

Client_ID:"5c7db1c9-02ce-499d-b20c-877b6c35c98d",
REDIRECT_URI:"http://localhost:4200/job-offer"

};
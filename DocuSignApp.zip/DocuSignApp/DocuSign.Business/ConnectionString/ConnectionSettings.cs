﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.DBCore.ConnectionString
{
    public class ConnectionSettings
    {
        public string DefaultConnection { get; set; }
    }
}

﻿using DocuSign.DBCore.Context.EFContext;

namespace DocuSign.DBCore.Factory
{
    public interface IContextFactory
    {
        IDatabaseContext DbContext { get; }
    }
}

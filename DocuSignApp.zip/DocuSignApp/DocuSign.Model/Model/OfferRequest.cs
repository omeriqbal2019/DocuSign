﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{
    public class OfferRequest
    {
        public string Content { get; set; }

        // Optional fields for enhanced functionality
        //public string Location { get; set; }
        //public string Position { get; set; }

        [Required(ErrorMessage = "Recipient name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string RecipientName { get; set; }

        [Required(ErrorMessage = "Recipient email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address format")]
        public string RecipientEmail { get; set; }

        ////[Required(ErrorMessage = "Offer content is required")]
        //// [MinLength(50, ErrorMessage = "Offer content must be at least 50 characters")]
        //public decimal? Salary { get; set; }
        //public string Schedule { get; set; }

        //// [Range(1, int.MaxValue, ErrorMessage = "Invalid salary value")]

        //public string StartDate { get; set; }

    }

    public enum EmploymentType
    {
        FullTime,
        PartTime,
        Contract,
        Internship,
        Temporary
    }

    public enum DocumentFormat
    {
        PDF,
        DOCX,
        HTML
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{
    public class EnvelopeStatus
    {
        public string EnvelopeId { get; set; } = Guid.NewGuid().ToString();

        // Status lifecycle: created → sent → delivered → signed → completed
        public string Status { get; set; } = "created";

        public string RecipientName { get; set; }
        public string RecipientEmail { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime? SentDate { get; set; }
        public DateTime? DeliveredDate { get; set; }
        public DateTime? SignedDate { get; set; }
        public DateTime? CompletedDate { get; set; }

        public string OfferId { get; set; }  // Reference to generated PDF
        public string DocumentUrl { get; set; }

        // Audit trail
        public List<StatusEvent> Events { get; set; } = new();

        // Digital signature metadata
        public string SignatureIpAddress { get; set; }
        public string SignatureLocation { get; set; }
        public string SignatureDevice { get; set; }
        public DateTime Created { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class StatusEvent
    {
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string EventType { get; set; }  // sent, viewed, signed, etc.
        public string Description { get; set; }
    }
}

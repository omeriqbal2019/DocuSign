﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{
    public class DocuSignatureRequestReceiver
    {

        public DocuSignatureRequest? obj { get; set; }

    }
    public class DocuSignatureRequest
    {
     
        public string? signerEmail { get; set; }
     
        public string? signerName { get; set; }
     

        public string? offerId { get; set; }
    }
}

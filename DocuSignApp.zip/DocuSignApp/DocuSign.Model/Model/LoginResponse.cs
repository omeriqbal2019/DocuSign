﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{

    public class Account
    {
        public string account_id { get; set; }
        public bool is_default { get; set; }
        public string account_name { get; set; }
        public string base_uri { get; set; }
    }

    public class LoginResponse
    {
        public string sub { get; set; }
        public string name { get; set; }
        public string given_name { get; set; }
        public string family_name { get; set; }
        public DateTime created { get; set; }
        public string email { get; set; }
        public List<Account> accounts { get; set; }
    }


}

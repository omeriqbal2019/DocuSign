﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{
    public class RecipientViewRequestModel
    {
        public string signerEmail { get; set; }
        public string signerName { get; set; }
        public string returnUrl { get; set; }
        public string signerClientId { get; set; }
        public string pingUrl { get; set; }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Model
{
    public class DocuSignRequestModel
    {
        public string OfferId { get; set; }
        public string RecipientEmail { get; set; }
        public string RecipientName { get; set; }
    }

 

    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Dto
{
    public class MetaDataRequestDto
    {
        public Guid? Offer_ID { get; set; }
        public string EnvelopID { get; set; }
        public string RecipantName { get; set; }
        public string RecipantEmail { get; set; }
        public string EnvelopStatus { get; set; }
    }
    public class MetaDataUpdateRequestDto
    {
        public Guid? Offer_ID { get; set; }
        public string EnvelopID { get; set; }
        public string EnvelopStatus { get; set; }
    }
}

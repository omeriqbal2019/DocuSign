﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Entity
{
    [Table("Document_Metadata")]
    public class MetaData
    {
        [Key]
        
        public int MetaData_Id { get; set; }
        public Guid? Offer_ID { get; set; }
        public string EnvelopID { get; set; }
        public string RecipantName { get; set; }
        public string RecipantEmail { get; set; }
        public string EnvelopStatus { get; set; }

    }
}

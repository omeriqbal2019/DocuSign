﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Model.Entity
{
    [Table("TokenDetail")]
    public class TokenDetail
    {
        [Key]
        public int TokenID { get; set; }
        public string Token { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}

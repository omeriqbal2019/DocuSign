﻿using Microsoft.AspNetCore.Identity;

namespace DocuSign.Model.identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}

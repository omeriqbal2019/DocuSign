﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Service.Services
{
    public interface IPDFService
    {
        Task<byte[]> GeneratePdf(string htmlContent);
    }
}

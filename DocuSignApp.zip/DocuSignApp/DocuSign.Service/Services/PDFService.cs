﻿using iText.Html2pdf;
using iText.Kernel.Pdf;
using PuppeteerSharp.Media;
using PuppeteerSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocuSign.Service.Services
{
    public class PDFService:IPDFService
    {
        public async Task<byte[]> GeneratePdf(string htmlContent)
        {
            MemoryStream ms = new MemoryStream();
            PdfWriter writer = new PdfWriter(ms);
            HtmlConverter.ConvertToPdf(htmlContent, writer);
            return ms.ToArray();

        }

      
    }
}

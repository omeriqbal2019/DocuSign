﻿
using DocuSign.DBCore.Unitofwork;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using DocuSign.Model.Dto;
using DocuSign.Model.Entity;
using DocuSign.Model.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;
using static DocuSign.eSign.Client.Auth.OAuth.UserInfo;


namespace DocuSign.Service.Services
{
    public class DocusignService : IDocusignService
    {
        private static readonly Dictionary<string, EnvelopesApi> _envelopes = new();
        private readonly IPDFService _pdfService;
        private readonly IConfiguration _config;
        private readonly IUnitOfWork _unitOfWork;
           private readonly ILoggerManager _log;
        public DocusignService(IPDFService pdfService, IConfiguration config, IUnitOfWork unitOfWork,ILoggerManager log)
        {
            _pdfService = pdfService;
            _config = config;
            _log = log;
            _unitOfWork = unitOfWork;
        }
    
        public Task<EnvelopeDefinition> MakeEnvelope(string signerEmail, string signerName, string signerClientId, string docPdf)
        {
  
            byte[] buffer = System.IO.File.ReadAllBytes(docPdf);

            EnvelopeDefinition envelopeDefinition = new EnvelopeDefinition();
            envelopeDefinition.EmailSubject = "Please sign this document";
            Document doc1 = new Document();

            string doc1B64 = Convert.ToBase64String(buffer);

            doc1.DocumentBase64 = doc1B64;
            doc1.Name = signerEmail +"-"+ signerClientId+"-"+DateTime.Now.Ticks; // can be different from actual file name
            doc1.FileExtension = "pdf";
            doc1.DocumentId = "3";

            envelopeDefinition.Documents = new List<Document> { doc1 };

             Signer signer1 = new Signer
            {
                Email = signerEmail,
                Name = signerName,
                ClientUserId = signerClientId,
                RecipientId = "1",
            };

             SignHere signHere1 = new SignHere
            {
                AnchorString = "/sn1/",
                AnchorUnits = "pixels",
                AnchorXOffset = "10",
                AnchorYOffset = "20",
            };

            Tabs signer1Tabs = new Tabs
            {
                SignHereTabs = new List<SignHere> { signHere1 },
            };
            signer1.Tabs = signer1Tabs;

            Recipients recipients = new Recipients
            {
                Signers = new List<Signer> { signer1 },
            };
            envelopeDefinition.Recipients = recipients;
             envelopeDefinition.Status = "sent";

            return  Task.FromResult(envelopeDefinition);
        }
        public Task<RecipientViewRequest> MakeRecipientViewRequest(string signerEmail, string signerName, string returnUrl, string signerClientId, string pingUrl = null)
        {
           
            RecipientViewRequest viewRequest = new RecipientViewRequest();

            viewRequest.ReturnUrl = returnUrl + "?state=123";

        
            viewRequest.AuthenticationMethod = "none";

          
            viewRequest.Email = signerEmail;
            viewRequest.UserName = signerName;
            viewRequest.ClientUserId = signerClientId;

       
            if (pingUrl != null)
            {
                viewRequest.PingFrequency = "600";
                viewRequest.PingUrl = pingUrl; 
            }

            return Task.FromResult(viewRequest);
        }

        public Task<Envelope> GetEnvelopeStatus(string accountId,string envelopeId, string basePath,string token)
        {
            var docuSignClient = new DocuSignClient(basePath);
            docuSignClient.Configuration.DefaultHeader.Add("Authorization", "Bearer " + token);

            EnvelopesApi envelopesApi = new EnvelopesApi(docuSignClient);
            return Task.FromResult(envelopesApi.GetEnvelope(accountId, envelopeId));
        }

        public Task<string> SaveMetaData(MetaDataRequestDto metaData)
        {
            try { 
            var metaRepository = _unitOfWork.GetRepository<MetaData>();
            var metadata = metaRepository.FindBy(u => u.EnvelopID == metaData.EnvelopID).FirstOrDefault();
            if (metadata != null)
                return null;

            MetaData _data = new MetaData();
            _data.Offer_ID = metaData.Offer_ID;
            _data.RecipantName = metaData.RecipantName;
            _data.RecipantEmail = metaData.RecipantEmail;
            _data.EnvelopStatus = metaData.EnvelopStatus;
            _data.EnvelopID = metaData.EnvelopID;
            metaRepository.Add(_data);
            _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                _log.WriteErrorMsg(string.Empty, string.Empty, currentMethod.Name, ex.Message);



            }
            return Task.FromResult("Saved");
        }
        public Task<string> UpdateMetadataStatus(MetaDataUpdateRequestDto metaData)
        {
            try { 
            var metaRepository = _unitOfWork.GetRepository<MetaData>();
            var metadata = metaRepository.FindBy(u => u.EnvelopID == metaData.EnvelopID).FirstOrDefault();
            if (metadata != null)
            
            metadata.EnvelopStatus = metaData.EnvelopStatus;
            
            metaRepository.Update(metadata);
            _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                _log.WriteErrorMsg(string.Empty, string.Empty, currentMethod.Name, ex.Message);
            }
            return Task.FromResult("Update");
        }
        public Task<MetaData> GetMetadataStatus(string EnvelopID,string  EnvelopStatus)
        {
            var metaRepository = _unitOfWork.GetRepository<MetaData>();
            var metadata = metaRepository.FindBy(u => u.EnvelopID == EnvelopID).FirstOrDefault();
            if (metadata != null)
                return Task.FromResult(metadata);
            else
                return Task.FromResult(new MetaData());
        }
        public Task<string> getToken()
        {
            var tokenRepository = _unitOfWork.GetRepository<TokenDetail>();
            var tokendata = tokenRepository.FindBy(x=>x.TokenID==1).FirstOrDefault().Token;
            return Task.FromResult(tokendata);

        }
        public Task<string> SaveToken(string tokenrequest)
        {
            try { 
            var tokenRepository = _unitOfWork.GetRepository<TokenDetail>();
            var tokendata = tokenRepository.GetAll().FirstOrDefault();
            if (tokendata != null)
            { 
                tokendata.Token = tokenrequest;
            tokendata.UpdatedAt = DateTime.Now;

            tokenRepository.Update(tokendata);
            _unitOfWork.Commit();
            }
            else
            {
                TokenDetail _data = new TokenDetail();
                _data.Token = tokenrequest;
                _data.UpdatedAt = DateTime.Now;

                tokenRepository.Add(_data);
                _unitOfWork.Commit();
            }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                _log.WriteErrorMsg(string.Empty, string.Empty, currentMethod.Name, ex.Message);
            }
            return Task.FromResult(tokenrequest);
        }
    }
}

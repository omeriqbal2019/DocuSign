﻿using DocuSign.eSign.Model;
using DocuSign.Model.Dto;
using DocuSign.Model.Entity;
using DocuSign.Model.Model;
namespace DocuSign.Service.Services
{
    public interface IDocusignService
    {
        Task<Envelope> GetEnvelopeStatus(string accountId, string envelopeId, string basePath, string token);
        Task<EnvelopeDefinition> MakeEnvelope(string signerEmail, string signerName, string signerClientId, string docPdf);
        Task<RecipientViewRequest> MakeRecipientViewRequest(string signerEmail, string signerName, string returnUrl, string signerClientId, string pingUrl = null);
        Task<string> SaveMetaData(MetaDataRequestDto metaData);
        Task<string> UpdateMetadataStatus(MetaDataUpdateRequestDto metaData);
        Task<MetaData> GetMetadataStatus(string EnvelopID, string EnvelopStatus);
        Task<string> SaveToken(string tokenrequest);
        Task<string> getToken();


    }
}

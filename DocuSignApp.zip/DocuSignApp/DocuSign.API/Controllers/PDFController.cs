﻿using DinkToPdf;
using DinkToPdf.Contracts;
using DocuSign.Model.Model;
using DocuSign.Service.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;

using static DocuSign.eSign.Client.Auth.OAuth;
using DocuSign.eSign.Client.Auth;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using System.Threading;
using System.Security.Cryptography;
using static DocuSign.eSign.Client.Auth.OAuth.UserInfo;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DocuSign.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PDFController : ControllerBase
    {
        private readonly IPDFService _pdfService; 
        private readonly IDocusignService _docusignService;
        private readonly ILoggerManager _log;
        public PDFController(IPDFService pdfService, IDocusignService docusignService, ILoggerManager log)
        {
            _pdfService = pdfService;
            _docusignService = docusignService;
            _log = log;

        }
      

        [HttpPost("generate")]

        public async Task<IActionResult> GenerateOffer([FromBody] OfferRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                var offerId = Guid.NewGuid().ToString();
            var pdfBytes = await _pdfService.GeneratePdf(request.Content);
            string path=await StorePdf(pdfBytes, offerId);

                return Ok(new { offerId });
            }
            catch (Exception ex)
            {
                _log.WriteErrorMsg(this.ControllerContext.RouteData.Values["controller"].ToString(), this.ControllerContext.RouteData.Values["action"].ToString(), null, ex.Message);


            }
            return Ok();
        }

        private async Task<string> StorePdf(byte[] pdfBytes, string offerId)
        {
            var path = Path.Combine("GeneratedPdfs", $"{offerId}.pdf");
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                await System.IO.File.WriteAllBytesAsync(path, pdfBytes);
            }
            catch(Exception ex)
            {
                _log.WriteErrorMsg(this.ControllerContext.RouteData.Values["controller"].ToString(), this.ControllerContext.RouteData.Values["action"].ToString(), null, ex.Message);
            }
        
            return path;
        }
      
    }
}

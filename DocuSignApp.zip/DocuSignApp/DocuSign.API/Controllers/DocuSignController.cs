﻿using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using DocuSign.Model;
using DocuSign.Model.Dto;
using DocuSign.Model.Model;
using DocuSign.Service.Services;
using Microsoft.AspNetCore.Mvc;


namespace DocuSign.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocuSignController : ControllerBase
    {
        private readonly HttpClient _httpClient;
        private readonly IDocusignService _docusignService;
        private readonly IConfiguration _config;
        private readonly ILoggerManager _log;
        public DocuSignController(IDocusignService docusignService,IConfiguration config, HttpClient httpClient, ILoggerManager log)
        {
            _docusignService = docusignService;
            _config = config;
            _httpClient = httpClient;
            _log = log;
   
        }
      

        [HttpPost("SetJwtToken")]
        public async Task<IActionResult> JwtToken(TokenRequest request)
        {
            try
            {
                //_token.token = request.token;
                var tokendetailData = await _docusignService.SaveToken(request.token);
                await _docusignService.SaveToken(request.token);
      
                return Ok(new { tokendetailData });
            }
            catch (Exception ex)
            {
                _log.WriteErrorMsg(this.ControllerContext.RouteData.Values["controller"].ToString(), this.ControllerContext.RouteData.Values["action"].ToString(), null, ex.Message);
            }

            return Ok(new { request.token });
        }


        [HttpPost("sendForSignature")]
        public async Task<IActionResult> CreateEnvelope([FromBody] DocuSignatureRequestReceiver request )
        {
            string redirectUrl = string.Empty;
     
            try
            {
                string accountId = _config.GetValue<string>("DocuSign:Account_ID").ToString();
                string accountBaseURL = _config.GetValue<string>("DocuSign:AccountBaseURL").ToString();
                string clientId = _config.GetValue<string>("DocuSign:ClientId").ToString();
                string returnURL = _config.GetValue<string>("DocuSign:REDIRECT_URI").ToString();
                var token = await _docusignService.getToken();
                var path = Path.Combine("GeneratedPdfs", $"{request.obj.offerId}.pdf");
                
                var envelope = await _docusignService.MakeEnvelope(request.obj.signerEmail, request.obj.signerName, clientId, path);

                var docuSignClient = new DocuSignClient(accountBaseURL);
                docuSignClient.Configuration.DefaultHeader.Add("Authorization", "Bearer " + token);

                EnvelopesApi envelopesApi = new EnvelopesApi(docuSignClient);
                EnvelopeSummary results = envelopesApi.CreateEnvelope(accountId, envelope);
                string envelopeId = results.EnvelopeId;

                var viewRequest = await _docusignService.MakeRecipientViewRequest(request.obj.signerEmail, request.obj.signerName, returnURL, clientId);

                ViewUrl results1 = envelopesApi.CreateRecipientView(accountId, envelopeId, viewRequest);

                 redirectUrl = results1.Url;

                var status = await _docusignService.GetEnvelopeStatus(accountId, envelopeId, accountBaseURL, token);
                MetaDataRequestDto dto = new MetaDataRequestDto()
                {
                    Offer_ID = Guid.Parse(request.obj.offerId),
                    EnvelopID = envelopeId,
                    RecipantEmail = request.obj.signerEmail,
                    RecipantName = request.obj.signerName,
                    EnvelopStatus = status.Status

                };

                await _docusignService.SaveMetaData(dto);

            }
            catch(Exception ex)
            {
                _log.WriteErrorMsg(this.ControllerContext.RouteData.Values["controller"].ToString(), this.ControllerContext.RouteData.Values["action"].ToString(), null, ex.Message);
            }
           
            return Ok(new { redirectUrl });
        }



      


    }
}

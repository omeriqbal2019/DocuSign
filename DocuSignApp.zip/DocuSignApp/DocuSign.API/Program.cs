using DinkToPdf;
using DinkToPdf.Contracts;
using DocuSign.DBCore.ConnectionString;
using DocuSign.DBCore.Context.EFContext;
using DocuSign.DBCore.Factory;
using DocuSign.DBCore.Repositories;
using DocuSign.DBCore.Unitofwork;
using DocuSign.eSign.Client;
using DocuSign.Model;
using DocuSign.Service.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using PuppeteerSharp;
using System.Reflection;

namespace DocuSignAPP
{
    public class Program
    {
        public  IConfiguration Configuration { get; }
        public Program(IConfiguration configuration)
        {
            Configuration = configuration;
        }
    
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            builder.Services.AddHttpClient<IDocusignService, IDocusignService>();
            builder.Services.AddTransient<IPDFService, PDFService>();
            builder.Services.AddTransient<IDocusignService, DocusignService>();
            builder.Services.Configure<ConnectionSettings>(builder.Configuration.GetSection("ConnectionStrings"));
            builder.Services.AddDbContext<DatabaseContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            builder.Services.AddScoped<IDatabaseContext, DatabaseContext>();
            builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            builder.Services.AddTransient<IContextFactory, ContextFactory>();
            builder.Services.AddTransient<IUnitOfWork, UnitOfWork>();
            builder.Services.AddSingleton<ILoggerManager, LoggerManager>();
            // Set token value from configuration/app secrets


            builder.Services.AddCors(options =>
            {
                options.AddPolicy("Default", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyHeader()
                          .AllowAnyMethod();
                });
            });

            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Job Offer Management API",
                    Version = "v1",
                    Description = "API for managing job offers and DocuSign integration"
                });
                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });
            var app = builder.Build();
            var revisionInfo =  new BrowserFetcher();

            app.UseCors("Default");
            // Configure the HTTP request pipeline.
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Job Offer Management API V1");
            });
            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
